import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-upload-members',
  templateUrl: './upload-members.component.html',
  styleUrls: ['./upload-members.component.scss']
})
export class UploadMembersComponent implements OnInit {

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
  }


  onSubmit(form : NgForm){
    console.log(form.value)
    this.http.post('http://nuru.sikika-ke.co.ke/pastors/uploadexcel', form.value).subscribe(
      responseData => {
        console.log(responseData)
        form.reset()
      }
    )
  }
}
