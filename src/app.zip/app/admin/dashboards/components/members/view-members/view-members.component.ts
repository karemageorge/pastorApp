import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-view-members',
  templateUrl: './view-members.component.html',
  styleUrls: ['./view-members.component.scss']
})
export class ViewMembersComponent implements OnInit {

  members : any = []

  constructor(private http : HttpClient) { }

  ngOnInit(): void {

    this.http.get<{ [key:string]: [] }>('http://nuru.sikika-ke.co.ke/pastors/members').pipe(map(
      responseData => {
        for (const key in responseData){
          if (responseData.hasOwnProperty(key)){
            this.members = responseData[key]
          } 
        }
       return this.members
      }
    )).subscribe( groupData =>{
      this.members = groupData 
      console.log(groupData)
    }  )
  }
  

}
