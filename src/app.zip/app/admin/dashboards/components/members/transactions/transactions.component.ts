import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { LayoutService } from 'src/app/admin/layout/services/layout.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit {
  members : any = []
  pastorinfo : any 

  constructor(private http : HttpClient, private layoutService: LayoutService) { }

  ngOnInit() {
    this.http.get<{ [key:string]: [] }>('http://nuru.sikika-ke.co.ke/pastors/getinfo').subscribe( groupData =>{
      this.pastorinfo = groupData 
      console.log(groupData)
    }  )

    this.http.get<{ [key:string]: [] }>('http://nuru.sikika-ke.co.ke/churches/confirmation').pipe(map(
      responseData => {
        for (const key in responseData){
          if (responseData.hasOwnProperty(key)){
            this.members = responseData[key]
          } 
        }
       return this.members
      }
    )).subscribe( groupData =>{
      this.members = groupData 
      console.log(this.members)
    }  )

  }
  toggleRightBar(){
    this.layoutService.toggleRightBar();
  }
}
