import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-view-sms',
  templateUrl: './view-sms.component.html',
  styleUrls: ['./view-sms.component.scss']
})
export class ViewSmsComponent implements OnInit {

  smss: any = []
  error = ""

  constructor(private http : HttpClient) { }

  ngOnInit(): void {
    this.http.get<{ [key:string]: [] }>('http://nuru.sikika-ke.co.ke/pastors/sendsms').pipe(map(
      responseData => {
        for (const key in responseData){
          if (responseData.hasOwnProperty(key)){
            this.smss = responseData[key]
          } 
        }
       return this.smss
      }
    )).subscribe( groupData =>{
      this.smss = groupData 
      console.log(groupData)
    }  )
  }

}
