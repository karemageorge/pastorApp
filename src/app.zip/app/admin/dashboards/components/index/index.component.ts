import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { LayoutService } from '../../../layout/services/layout.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {
  members : any = []
  pastorinfo : any 

  constructor(private layoutService: LayoutService, private http : HttpClient) { }

  ngOnInit() {
    this.http.get<{ [key:string]: [] }>('http://nuru.sikika-ke.co.ke/pastors/getinfo').subscribe( groupData =>{
      this.pastorinfo = groupData 
      console.log(groupData)
    }  )

    this.http.get<{ [key:string]: [] }>('http://nuru.sikika-ke.co.ke/pastors/members').pipe(map(
      responseData => {
        for (const key in responseData){
          if (responseData.hasOwnProperty(key)){
            this.members = responseData[key]
          } 
        }
       return this.members
      }
    )).subscribe( groupData =>{
      this.members = groupData 
      console.log(groupData)
    }  )

  }

  toggleRightBar(){
    this.layoutService.toggleRightBar();
  }

}
